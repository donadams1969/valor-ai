export const RUNTIME_PRINCIPLES = {
  purpose: "Evidence preservation and organization",

  claimsBoundary:
    "The system does not independently determine intent, liability, or criminal findings.",

  privacy: "Sensitive anchor data remains redacted in public surfaces.",

  routing: "Unknown paths resolve through bounded recovery.",

  runtime: "Local execution remains deterministic and auditable.",
} as const;
