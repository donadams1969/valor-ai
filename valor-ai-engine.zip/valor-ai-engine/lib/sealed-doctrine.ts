export const SEALED_DOCTRINE = {
  governance: "14D Core",
  status: "Latched",
  version: "V1000",
};
