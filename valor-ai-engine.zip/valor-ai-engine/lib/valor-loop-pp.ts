export const ValorLoopPP = {
  renderSafe: (data: any) => JSON.stringify(data, null, 2),
};
