import React from "react";

export default function StasisPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-white font-mono p-8 flex flex-col items-center justify-center">
      <div className="max-w-2xl text-center space-y-6">
        <h1 className="text-3xl font-bold uppercase tracking-widest text-slate-500">
          Internal Verification Surface
        </h1>
        <p className="text-sm text-slate-400 italic">
          This surface is observational only. No legal conclusions are rendered
          here.
        </p>
        <div className="p-4 border border-slate-800 bg-slate-900 rounded-lg">
          <p className="text-xs text-slate-500 uppercase tracking-widest">
            Status: STASIS
          </p>
        </div>
      </div>
    </div>
  );
}
