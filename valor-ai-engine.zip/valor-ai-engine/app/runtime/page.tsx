import { ValorLoopPP } from "@/lib/valor-loop-pp";
import { SEALED_DOCTRINE } from "@/lib/sealed-doctrine";
import { RUNTIME_PRINCIPLES } from "@/lib/runtime-principles";

export default function RuntimeManifestPage() {
  const manifest = {
    doctrine: SEALED_DOCTRINE,
    runtimePrinciples: RUNTIME_PRINCIPLES,
  };

  return (
    <main className="min-h-screen bg-black text-white p-8">
      <section className="max-w-5xl mx-auto">
        <h1 className="text-4xl font-black mb-6">Runtime Manifest</h1>

        <pre className="rounded-xl bg-neutral-950 border border-neutral-800 p-4 overflow-auto text-sm">
          {ValorLoopPP.renderSafe(manifest)}
        </pre>
      </section>
    </main>
  );
}
