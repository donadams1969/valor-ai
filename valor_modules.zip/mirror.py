# VALOR-Mirror: Institutional response profiler and simulator

def simulate_response(entity_name):
    scenarios = {
        "silence": "No reply received. Flagging for legal escalation.",
        "deflect": f"{entity_name} issued vague reply. Logged and time-stamped.",
        "engage": f"{entity_name} requested negotiation. Risk profile: active."
    }
    return scenarios
