# VALOR-EvidenceVault: Blockchain-sealed exhibit archiver

import hashlib

def seal_to_blockchain(data):
    return hashlib.sha256(data.encode()).hexdigest()
