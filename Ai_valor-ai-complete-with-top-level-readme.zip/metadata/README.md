# Metadata

Includes all JSON metadata like manifest.web3.json, NFT payloads, and evidence descriptors.
