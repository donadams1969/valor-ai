# Nft-certificates

Holds NFT-sealed PDFs, OTS hash logs, certificate JSONs, and digital compliance artifacts.
