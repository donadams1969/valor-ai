# Scripts

Automation scripts such as Python hash signers, IPFS uploaders, and CLI tools.
