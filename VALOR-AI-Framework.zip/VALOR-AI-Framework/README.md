# VALOR AI+
This repository contains the framework for decentralized legal accountability.