# VALOR AI Core
Legal logic and compliance map.