# Legal NFTs
NFT metadata and mint logs.